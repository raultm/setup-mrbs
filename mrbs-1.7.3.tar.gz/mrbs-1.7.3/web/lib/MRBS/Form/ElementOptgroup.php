<?php

namespace MRBS\Form;


class ElementOptgroup extends Element
{
  
  public function __construct()
  {
    parent::__construct('optgroup');
  }
  
}