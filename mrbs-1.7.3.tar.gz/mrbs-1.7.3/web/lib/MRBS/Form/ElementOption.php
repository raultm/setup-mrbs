<?php

namespace MRBS\Form;


class ElementOption extends Element
{
  
  public function __construct()
  {
    parent::__construct('option');
  }
  
}